﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
 * name: mehul khosla
 * date:july 21, 2017
 * description: this is an interface that defines a MoonCount property that
 * must be implmented in any class that subscribr to it
 * version:0.1- created interface IHasMoon.
 */
namespace Abstract_Planets
{
    /// <summary>
    /// this is IHasMoon interface
    /// </summary>
    public interface IHasMoon
    {
        //public property
        bool HasMoon();

      
    }



}